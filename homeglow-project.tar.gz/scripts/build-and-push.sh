#!/bin/bash

###############################################################################
# HomeGlow Docker Image Build and Push Script
#
# This script builds multi-architecture Docker images for HomeGlow and pushes
# them to GitHub Container Registry (GHCR).
#
# Prerequisites:
# 1. Docker with buildx support installed
# 2. Authenticated with GHCR: echo $GITHUB_TOKEN | docker login ghcr.io -u USERNAME --password-stdin
# 3. Run from the project root directory
#
# Usage:
#   ./scripts/build-and-push.sh [VERSION]
#
# Examples:
#   ./scripts/build-and-push.sh           # Uses 'latest' tag
#   ./scripts/build-and-push.sh 1.2.0     # Uses '1.2.0' tag
#   ./scripts/build-and-push.sh dev       # Uses 'dev' tag
#
###############################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# GitHub repository info
GITHUB_USERNAME="jherforth"
REPO_NAME="homeglow"

# Get version tag from argument or default to 'latest'
VERSION="${1:-latest}"

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║          HomeGlow Docker Image Build & Push Script           ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Validate we're in the project root
if [ ! -f "docker-compose.yml" ] || [ ! -d "client" ] || [ ! -d "server" ]; then
    echo -e "${RED}Error: This script must be run from the project root directory${NC}"
    exit 1
fi

echo -e "${YELLOW}Version:${NC} $VERSION"
echo -e "${YELLOW}Registry:${NC} ghcr.io"
echo -e "${YELLOW}Username:${NC} $GITHUB_USERNAME"
echo -e "${YELLOW}Repository:${NC} $REPO_NAME"
echo -e "${YELLOW}Architectures:${NC} linux/amd64, linux/arm64"
echo ""

# Check if user is logged in to GHCR
if ! docker info 2>/dev/null | grep -q "ghcr.io"; then
    echo -e "${YELLOW}Warning: You may not be logged in to GHCR${NC}"
    echo -e "${YELLOW}To login, run:${NC} echo \$GITHUB_TOKEN | docker login ghcr.io -u $GITHUB_USERNAME --password-stdin"
    echo ""
fi

# Confirm before building
read -p "$(echo -e ${YELLOW}Continue with build and push? [y/N]:${NC} )" -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${RED}Build cancelled${NC}"
    exit 0
fi

echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Step 1/4: Setting up Docker Buildx${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"

# Create buildx builder if it doesn't exist
if ! docker buildx ls | grep -q "homeglow-builder"; then
    echo -e "${YELLOW}Creating new buildx builder...${NC}"
    docker buildx create --name homeglow-builder --use
else
    echo -e "${YELLOW}Using existing buildx builder...${NC}"
    docker buildx use homeglow-builder
fi

# Bootstrap the builder
docker buildx inspect --bootstrap

echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Step 2/4: Building Server Image${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"

SERVER_IMAGE="ghcr.io/$GITHUB_USERNAME/${REPO_NAME}-server:$VERSION"
echo -e "${YELLOW}Building:${NC} $SERVER_IMAGE"

docker buildx build \
    --platform linux/amd64,linux/arm64 \
    --tag "$SERVER_IMAGE" \
    --push \
    --file ./server/Dockerfile \
    --build-arg PORT=5000 \
    ./server

echo -e "${GREEN}✓ Server image built and pushed successfully${NC}"

echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Step 3/4: Building Client Image${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"

CLIENT_IMAGE="ghcr.io/$GITHUB_USERNAME/${REPO_NAME}-client:$VERSION"
echo -e "${YELLOW}Building:${NC} $CLIENT_IMAGE"

docker buildx build \
    --platform linux/amd64,linux/arm64 \
    --tag "$CLIENT_IMAGE" \
    --push \
    --file ./client/Dockerfile \
    --build-arg PORT=3000 \
    ./client

echo -e "${GREEN}✓ Client image built and pushed successfully${NC}"

echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Step 4/4: Tagging 'latest' (if building a version)${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"

# If version is not 'latest' and looks like a semver, also tag as latest
if [[ "$VERSION" != "latest" ]] && [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo -e "${YELLOW}Version $VERSION detected, also tagging as 'latest'...${NC}"

    # Re-tag and push as latest
    LATEST_SERVER="ghcr.io/$GITHUB_USERNAME/${REPO_NAME}-server:latest"
    LATEST_CLIENT="ghcr.io/$GITHUB_USERNAME/${REPO_NAME}-client:latest"

    docker buildx build \
        --platform linux/amd64,linux/arm64 \
        --tag "$LATEST_SERVER" \
        --push \
        --file ./server/Dockerfile \
        --build-arg PORT=5000 \
        ./server

    docker buildx build \
        --platform linux/amd64,linux/arm64 \
        --tag "$LATEST_CLIENT" \
        --push \
        --file ./client/Dockerfile \
        --build-arg PORT=3000 \
        ./client

    echo -e "${GREEN}✓ Images also tagged as 'latest'${NC}"
else
    echo -e "${YELLOW}Skipping 'latest' tag (version is '$VERSION')${NC}"
fi

echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    Build Complete! 🎉                         ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}Images pushed:${NC}"
echo -e "  • $SERVER_IMAGE"
echo -e "  • $CLIENT_IMAGE"

if [[ "$VERSION" != "latest" ]] && [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo -e "  • $LATEST_SERVER"
    echo -e "  • $LATEST_CLIENT"
fi

echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo -e "  1. View packages: ${BLUE}https://github.com/$GITHUB_USERNAME?tab=packages${NC}"
echo -e "  2. Deploy: ${BLUE}docker-compose pull && docker-compose up -d${NC}"
echo -e "  3. Create release: ${BLUE}https://github.com/$GITHUB_USERNAME/$REPO_NAME/releases/new${NC}"
echo ""
