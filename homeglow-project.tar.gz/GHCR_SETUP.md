# GitHub Container Registry (GHCR) Setup Guide

This guide explains how to configure and use GitHub Container Registry for HomeGlow Docker images.

## Table of Contents

- [Overview](#overview)
- [Automated Builds with GitHub Actions](#automated-builds-with-github-actions)
- [Manual Build and Push](#manual-build-and-push)
- [Repository Configuration](#repository-configuration)
- [Pulling Images](#pulling-images)
- [Troubleshooting](#troubleshooting)

## Overview

HomeGlow uses GitHub Container Registry (GHCR) to host pre-built Docker images. This provides several benefits:

- **Zero build time** for users - just pull and run
- **Multi-architecture support** - works on x86_64 (Intel/AMD) and ARM64 (Raspberry Pi)
- **Automatic builds** via GitHub Actions on every release
- **Version tagging** for easy rollback and version management
- **Public access** - no authentication required to pull images

## Automated Builds with GitHub Actions

HomeGlow includes a GitHub Actions workflow that automatically builds and publishes Docker images to GHCR.

### Triggers

The workflow runs automatically on:

1. **Git Tags** - When you create a version tag (e.g., `v1.2.0`)
2. **Main Branch** - When you push to the main branch
3. **Manual Trigger** - Via GitHub's Actions tab

### Creating a Release

To publish a new version:

```bash
# Update version in package.json files
# Then create and push a git tag
git tag v1.2.0
git push origin v1.2.0
```

The workflow will automatically:
- Build server and client images for AMD64 and ARM64
- Tag images with multiple formats:
  - `latest` (for main branch)
  - `1.2.0` (semantic version)
  - `1.2` (major.minor)
  - `1` (major version)
  - `main-abc123` (git SHA)
- Push all images to GHCR
- Create a job summary with links to packages

### Monitoring Builds

1. Go to your repository on GitHub
2. Click the **Actions** tab
3. View workflow runs and build logs
4. Check job summaries for published image tags

## Manual Build and Push

For local builds and testing, use the provided build script.

### Prerequisites

1. **Docker with Buildx**
   ```bash
   docker buildx version
   ```

2. **GitHub Personal Access Token (PAT)**
   - Go to [GitHub Settings > Developer Settings > Personal Access Tokens](https://github.com/settings/tokens)
   - Click "Generate new token (classic)"
   - Select scopes: `write:packages`, `read:packages`, `delete:packages`
   - Copy the token

3. **Login to GHCR**
   ```bash
   echo $GITHUB_TOKEN | docker login ghcr.io -u jherforth --password-stdin
   ```

### Build and Push

```bash
# Build and push with 'latest' tag
./scripts/build-and-push.sh

# Build and push with specific version
./scripts/build-and-push.sh 1.2.0

# Build and push development version
./scripts/build-and-push.sh dev
```

The script will:
- Create a multi-architecture builder
- Build images for AMD64 and ARM64
- Push to GHCR with specified tags
- Optionally tag as 'latest' for semantic versions

### Build Script Features

- **Interactive confirmation** before building
- **Multi-architecture** support (AMD64, ARM64)
- **Automatic 'latest' tagging** for semantic versions
- **Colorized output** for easy reading
- **Error handling** with helpful messages

## Repository Configuration

### Making Images Public

By default, GHCR packages are private. To make them public:

1. Go to [GitHub Packages](https://github.com/jherforth?tab=packages)
2. Find `homeglow-server` and `homeglow-client` packages
3. Click on each package
4. Go to **Package Settings** (bottom right)
5. Scroll to **Danger Zone**
6. Click **Change visibility** → **Public**
7. Confirm the change

**Important:** Public images can be pulled without authentication, making deployment much simpler for users.

### Package Permissions

For automated builds via GitHub Actions, ensure the repository has permissions:

1. Go to repository **Settings** → **Actions** → **General**
2. Scroll to **Workflow permissions**
3. Select **Read and write permissions**
4. Check **Allow GitHub Actions to create and approve pull requests**
5. Click **Save**

## Pulling Images

### Public Images (No Authentication)

Once images are public, anyone can pull them:

```bash
# Pull latest version
docker pull ghcr.io/jherforth/homeglow-server:latest
docker pull ghcr.io/jherforth/homeglow-client:latest

# Pull specific version
docker pull ghcr.io/jherforth/homeglow-server:1.2.0
docker pull ghcr.io/jherforth/homeglow-client:1.2.0

# Pull for specific architecture
docker pull --platform linux/arm64 ghcr.io/jherforth/homeglow-server:latest
```

### Using Docker Compose

The production `docker-compose.yml` automatically pulls from GHCR:

```bash
# Pull and start services
docker-compose pull
docker-compose up -d

# Update to latest version
docker-compose pull
docker-compose up -d
```

### Version Pinning

For production stability, pin to specific versions:

```yaml
services:
  homeglow-backend:
    image: ghcr.io/jherforth/homeglow-server:1.2.0  # Pinned version
```

Or use `latest` for automatic updates:

```yaml
services:
  homeglow-backend:
    image: ghcr.io/jherforth/homeglow-server:latest  # Always latest
```

## Troubleshooting

### Authentication Errors

**Problem:** `unauthorized: unauthenticated`

**Solution:**
```bash
# Generate a PAT with package permissions
# Login to GHCR
echo $GITHUB_TOKEN | docker login ghcr.io -u jherforth --password-stdin
```

### Package Not Found

**Problem:** `manifest unknown: manifest unknown`

**Solutions:**
1. Ensure the image name is correct (lowercase, with username)
2. Check if package exists: [GitHub Packages](https://github.com/jherforth?tab=packages)
3. Verify the tag exists on the package page
4. Ensure packages are public (see [Making Images Public](#making-images-public))

### Build Failures

**Problem:** Workflow fails in GitHub Actions

**Solutions:**
1. Check workflow logs in **Actions** tab
2. Verify repository permissions (see [Package Permissions](#package-permissions))
3. Ensure Dockerfiles are valid
4. Check for syntax errors in workflow file

### Multi-Architecture Issues

**Problem:** Image won't run on Raspberry Pi (ARM64)

**Solutions:**
```bash
# Explicitly pull ARM64 image
docker pull --platform linux/arm64 ghcr.io/jherforth/homeglow-server:latest

# Verify image architectures
docker manifest inspect ghcr.io/jherforth/homeglow-server:latest
```

### Rate Limiting

**Problem:** GitHub Actions rate limits

**Solutions:**
- Use caching in workflows (already configured)
- Avoid rebuilding unchanged layers
- Consider building on-demand rather than on every push

## Image Tags Reference

HomeGlow uses the following tagging strategy:

| Tag Format | Example | Description |
|------------|---------|-------------|
| `latest` | `latest` | Latest stable release from main branch |
| Semantic Version | `1.2.0` | Specific release version |
| Major.Minor | `1.2` | Latest patch for major.minor |
| Major | `1` | Latest minor for major version |
| Branch-SHA | `main-abc123f` | Specific commit from branch |

## Best Practices

1. **Pin versions in production** - Use semantic versions for stability
2. **Test before deploying** - Pull and test images locally first
3. **Keep images public** - Simplifies deployment and sharing
4. **Use semantic versioning** - Makes version management easier
5. **Monitor builds** - Check GitHub Actions for build status
6. **Regular updates** - Pull latest images periodically for security updates

## Additional Resources

- [GitHub Container Registry Documentation](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry)
- [Docker Buildx Documentation](https://docs.docker.com/buildx/working-with-buildx/)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [HomeGlow Repository](https://github.com/jherforth/HomeGlow)

## Support

For issues related to:
- **Image building**: Check GitHub Actions logs
- **Image pulling**: Verify package visibility and authentication
- **Deployment**: See main [README.md](README.md) for deployment guides
- **Bugs**: Open an issue on [GitHub Issues](https://github.com/jherforth/HomeGlow/issues)
